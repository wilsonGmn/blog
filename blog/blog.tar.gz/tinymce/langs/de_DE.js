tinyMCE.addI18n({de_DE:{
shc:{	
desc : 'Insert an RSS Feed'
}}});