tinyMCE.addI18n({en:{
shc:{	
desc : 'Insert an RSS Feed'
}}});
