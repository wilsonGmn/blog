tinyMCE.addI18n({en_US:{
shc:{	
desc : 'Insert an RSS Feed'
}}});